{
	"name": "Queen Nyx Bot Multi Device "
    }
